import "./ContenidoPrincipal.css";

const ContenidoPrincipal = ({ children }) => {
  return <main className="contenidoPrincipal">{children}</main>;
};

export default ContenidoPrincipal;
