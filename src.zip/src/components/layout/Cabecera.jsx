const Cabecera = ({ children }) => {
  return <header className="cabecera">{children}</header>;
};

export default Cabecera;
