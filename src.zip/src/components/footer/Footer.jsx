import "./footer.css";

const Footer = () => {
  return <footer className="pie">Pie de página</footer>;
};

export default Footer;
