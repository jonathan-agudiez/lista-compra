import { useState } from "react";
import useCompra from "../../hooks/useCompra.js";
import "./ProductosListado.css";

/*
  Listado del catálogo (tabla products) con filtros y ordenación.
  Esto es la ampliación de la práctica 6.08 dentro de /compra.
*/
const ProductosListado = () => {
  const { catalogo, cargando } = useCompra();

  // filtroActivo: "ninguno" | "nombre" | "precio" | "peso"
  const [filtroActivo, setFiltroActivo] = useState("ninguno");
  const [textoNombre, setTextoNombre] = useState("");
  const [precioMax, setPrecioMax] = useState("");
  const [pesoMax, setPesoMax] = useState("");

  // ordenarPor: "name" | "price" | "weight"
  const [ordenarPor, setOrdenarPor] = useState("name");

  // Cuando se cambia el filtro, se limpian los otros valores
  const cambiarFiltro = (nuevo) => {
    setFiltroActivo(nuevo);
    setTextoNombre("");
    setPrecioMax("");
    setPesoMax("");
  };

  // Copia del catálogo para trabajar
  const lista = catalogo ? catalogo : [];

  // 1) Filtrado (solo uno activo)
  const filtrados = [];

  for (let i = 0; i < lista.length; i++) {
    const p = lista[i];
    let ok = true;

    if (filtroActivo === "nombre") {
      const nombre = p && p.name ? p.name.toLowerCase() : "";
      const buscado = textoNombre.toLowerCase();
      ok = nombre.indexOf(buscado) !== -1;
    }

    if (filtroActivo === "precio") {
      if (precioMax === "") {
        ok = true;
      } else {
        const max = Number(precioMax);
        if (p && p.price != null) ok = p.price <= max;
        else ok = false;
      }
    }

    if (filtroActivo === "peso") {
      if (pesoMax === "") {
        ok = true;
      } else {
        const max = Number(pesoMax);
        if (p && p.weight != null) ok = p.weight <= max;
        else ok = false;
      }
    }

    if (ok) filtrados.push(p);
  }

  // 2) Ordenación (simple y clara)
  // Se crea copia para no tocar el array original
  const ordenados = filtrados.slice();

  ordenados.sort(function (a, b) {
    const aName = a && a.name ? a.name : "";
    const bName = b && b.name ? b.name : "";

    const aPrice = a && a.price != null ? a.price : 999999999;
    const bPrice = b && b.price != null ? b.price : 999999999;

    const aWeight = a && a.weight != null ? a.weight : 999999999;
    const bWeight = b && b.weight != null ? b.weight : 999999999;

    if (ordenarPor === "name") {
      return aName.localeCompare(bName);
    }

    if (ordenarPor === "price") {
      return aPrice - bPrice;
    }

    // weight
    return aWeight - bWeight;
  });

  // 3) Resumen final: nº productos + precio medio
  const totalMostrados = ordenados.length;

  let sumaPrecios = 0;
  let cuentaPrecios = 0;

  for (let i = 0; i < ordenados.length; i++) {
    const p = ordenados[i];
    if (p && p.price != null) {
      sumaPrecios += p.price;
      cuentaPrecios += 1;
    }
  }

  let precioMedio = 0;
  if (cuentaPrecios > 0) {
    precioMedio = sumaPrecios / cuentaPrecios;
  }

  return (
    <section className="panel">
      <div className="panelTitulo">
        <h3>Catálogo de productos</h3>
      </div>

      <div className="productosBox">
        <div className="productosControles">
          <div className="productosFila">
            <label className="productosLabel">
              <span>Filtrar por</span>
              <select
                className="input"
                value={filtroActivo}
                onChange={(e) => cambiarFiltro(e.target.value)}
                disabled={cargando}
              >
                <option value="ninguno">Sin filtro</option>
                <option value="nombre">Nombre</option>
                <option value="precio">Precio máximo</option>
                <option value="peso">Peso máximo</option>
              </select>
            </label>

            <label className="productosLabel">
              <span>Ordenar por</span>
              <select
                className="input"
                value={ordenarPor}
                onChange={(e) => setOrdenarPor(e.target.value)}
                disabled={cargando}
              >
                <option value="name">Nombre</option>
                <option value="price">Precio</option>
                <option value="weight">Peso</option>
              </select>
            </label>
          </div>

          {filtroActivo === "nombre" ? (
            <label className="productosLabel">
              <span>Nombre contiene</span>
              <input
                className="input"
                value={textoNombre}
                onChange={(e) => setTextoNombre(e.target.value)}
                placeholder="Ej: leche"
                disabled={cargando}
              />
            </label>
          ) : (
            ""
          )}

          {filtroActivo === "precio" ? (
            <label className="productosLabel">
              <span>Precio máximo</span>
              <input
                className="input"
                type="number"
                value={precioMax}
                onChange={(e) => setPrecioMax(e.target.value)}
                placeholder="Ej: 3.5"
                disabled={cargando}
              />
            </label>
          ) : (
            ""
          )}

          {filtroActivo === "peso" ? (
            <label className="productosLabel">
              <span>Peso máximo</span>
              <input
                className="input"
                type="number"
                value={pesoMax}
                onChange={(e) => setPesoMax(e.target.value)}
                placeholder="Ej: 500"
                disabled={cargando}
              />
            </label>
          ) : (
            ""
          )}
        </div>

        <div className="productosResumen">
          <span>Mostrados: {totalMostrados}</span>
          <span>
            Precio medio:{" "}
            {cuentaPrecios > 0 ? precioMedio.toFixed(2) + " €" : "—"}
          </span>
        </div>

        <div className="productosLista">
          {ordenados.length === 0 ? (
            <div className="productosEmpty">No hay productos para mostrar.</div>
          ) : (
            ordenados.map((p) => (
              <article key={p.id} className="productoCard">
                <div className="productoTop">
                  <div className="productoNombre">{p.name}</div>
                  <div className="productoMeta">
                    <span>
                      Peso: {p.weight != null ? p.weight + " g" : "—"}
                    </span>
                    <span>
                      Precio: {p.price != null ? p.price + " €" : "—"}
                    </span>
                  </div>
                </div>

                {p.description ? (
                  <div className="productoDesc">{p.description}</div>
                ) : (
                  ""
                )}
              </article>
            ))
          )}
        </div>
      </div>
    </section>
  );
};

export default ProductosListado;
