import "./ContenedorGeneral.css";

const ContenedorGeneral = ({ children }) => {
  return <div className="layout">{children}</div>;
};

export default ContenedorGeneral;
